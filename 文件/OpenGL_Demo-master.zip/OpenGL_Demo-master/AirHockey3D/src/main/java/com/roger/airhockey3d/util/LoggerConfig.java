package com.roger.airhockey3d.util;

/**
 * Created by Administrator on 2016/6/30.
 */
public class LoggerConfig {
  public static final boolean ON = true;
}
