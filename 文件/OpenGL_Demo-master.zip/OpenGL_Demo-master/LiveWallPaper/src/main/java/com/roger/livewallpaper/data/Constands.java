package com.roger.livewallpaper.data;

/**
 * Created by Administrator on 2016/7/5.
 */
public class Constands {
  public static final int BYTES_PER_FLOAT = 4;
  public static final int BYTES_PER_SHORT = 2;
}
