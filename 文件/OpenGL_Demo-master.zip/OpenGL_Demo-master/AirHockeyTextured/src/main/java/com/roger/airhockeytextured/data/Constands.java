package com.roger.airhockeytextured.data;

/**
 * Created by Administrator on 2016/7/5.
 */
public class Constands {
  public static final int BYTES_PER_FLOAT = 4;
}
